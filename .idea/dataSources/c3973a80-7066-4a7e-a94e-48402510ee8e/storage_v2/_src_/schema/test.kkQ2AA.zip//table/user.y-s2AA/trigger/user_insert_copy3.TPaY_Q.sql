CREATE TRIGGER user_insert_copy3
  AFTER INSERT
  ON user
  FOR EACH ROW
  INSERT INTO manage_data_change_log (change_type,change_flag,change_pkey,change_time) VALUES('user','ins',NEW.id,now());

