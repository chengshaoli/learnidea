CREATE TRIGGER user_update_copy3
  AFTER UPDATE
  ON user
  FOR EACH ROW
  INSERT INTO manage_data_change_log (change_type,change_flag,change_pkey,change_time) VALUES('user','modi',NEW.id,now());

