CREATE TRIGGER user_delete_copy3
  AFTER DELETE
  ON user
  FOR EACH ROW
  INSERT INTO manage_data_change_log (change_type,change_flag,change_pkey,change_time) VALUES('user','del',OLD.id,now());

